const Discord = require("discord.js")

const config = require("./config.json")

const client = new Discord.Client({ 
  intents: [ 
    Discord.GatewayIntentBits.Guilds,
    Discord.GatewayIntentBits.GuildMessages,
    Discord.GatewayIntentBits.MessageContent,
    Discord.GatewayIntentBits.GuildMembers,
    '32767'
       ]
    });

module.exports = client

client.on('interactionCreate', (interaction) => {

  if(interaction.type === Discord.InteractionType.ApplicationCommand){

      const cmd = client.slashCommands.get(interaction.commandName);

      if (!cmd) return interaction.reply(`Error`);

      interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

      cmd.run(client, interaction)

   }
})

client.on('ready', () => {
  console.log(`🔥 Estou online em ${client.user.username}!`)
})
//call
const { joinVoiceChannel } = require('@discordjs/voice');

client.on("ready", () => {
  let canal = client.channels.cache.get("1217480836212064327") // coloque o ID do canal de voz
  if (!canal) return console.log("❌ Não foi possível entrar no canal de voz.")
  if (canal.type !== Discord.ChannelType.GuildVoice) return console.log(`❌ Não foi possível entrar no canal [ ${canal.name} ].`)

  try {

    joinVoiceChannel({
      channelId: '1215991371425513583', // ID do canal de voz
      guildId: '1215981426860752976', // ID do servidor
      adapterCreator: canal.guild.voiceAdapterCreator,
    })
    console.log(`✅ Entrei no canal de voz [ ${canal.name} ] com sucesso!`)

  } catch(e) {
    console.log(`❌ Não foi possível entrar no canal [ ${canal.name} ].`)
  }

});

//call

client.slashCommands = new Discord.Collection()

require('./handler')(client)

client.login(config.token)

client.on("interactionCreate", require('./events/config-ticket').execute);
client.on("interactionCreate", require('./events/ticket').execute);
client.on("interactionCreate", require('./events/gerenciar').execute);
client.on("interactionCreate", require('./events/sugestion').execute);


// discord.js
const { ActivityType } = require("discord.js");

// axios - request
const axios = require("axios");

// event
module.exports = {
    name: "ready",
    async execute(client) {

        // main logs
        console.log(`[LOG] ${client.user.username} is ready!`);

        // bot status
        const textStatus = `Atendendo Tickets`;
        client.user.setActivity(textStatus, {
            type: ActivityType.Custom
        });
        client.user.setStatus("online");

        // changes the bot description to the official one
        const description = `<a:emoji_24:1142605393852375090> Bot de Ticket por mensalidade\n<a:Aviso2:1153002548849029251> Personalizavel via comandos\n<a:Suporte:1153001753588011128> Barato\n Interessado? 👇🏼\n <:emoji_17:1199629785438105643><:emoji_18:1199629847014670427>\nhttps://discord.gg/48TDYvJjJW`
        await axios.patch(`https://discord.com/api/v10/applications/${client.user.id}`, {
            description: description
        }, {
            headers: {
                "Authorization": `Bot ${config.token}`,
                "Content-Type": 'application/json',
            }
        });

    },
};