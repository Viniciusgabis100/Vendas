const Discord = require('discord.js');
const config = require('../config.json');
const fs = require('fs')


module.exports = {
    name: 'sugestion',
    async execute(interaction) {
        const emojis = []


        if (interaction.isButton()) {
            if (interaction.customId.startsWith("sugestion")) {
              const painel_sugestion = new Discord.ModalBuilder()
                .setCustomId('painelsugestion')
                .setTitle(`Faça sua Avaliação ${interaction.user.username}`)
              const sugestion = new Discord.TextInputBuilder()
                .setCustomId('sugestion')
                .setLabel('Digite sua avaliação')
                .setPlaceholder('Escreva a Avaliação aqui.')
                .setStyle(Discord.TextInputStyle.Paragraph)
			 
              const firstActionRow = new Discord.ActionRowBuilder().addComponents(sugestion);
              painel_sugestion.addComponents(firstActionRow)
              await interaction.showModal(painel_sugestion);
            }
          }

      
          if (!interaction.isModalSubmit()) return;
          if (interaction.customId === 'painelsugestion') {
            const chanel = interaction.guild.channels.cache.get('1198746811641385071')
            const sugestao = interaction.fields.getTextInputValue('sugestion');
			
            const embed= new Discord.EmbedBuilder()
            .setDescription(`💫 | Avaliação dê ${interaction.user.username}`)
            .setAuthor({
                name: interaction.guild.name,
                iconURL: interaction.guild.iconURL({ dynamic: true }),
              })

			  .setColor('Random')
              .setThumbnail(
                `${interaction.user.displayAvatarURL({
                  dynamic: true,
                  format: "png",
                  size: 4096,
                })}`
              )
            
            
            .addFields(
                { name: "⭐️ | Avaliação:", value: sugestao}
			)
        
            chanel.send({ embeds: [embed] }).then( (msgg) => {
                        emojis.forEach(emoji => {
                            msgg.react(emoji)
                        })})


            interaction.reply({
                content:"✅️ | Sua Avaliação foi enviada com sucesso\n Obrigado por comprar conosco\n\n Volte Sempre 😁",
                ephemeral:true
            })

            
    }



}}