const { ApplicationCommandType, EmbedBuilder } = require("discord.js")
const { General } = require("../../DataBaseJson")

module.exports = {
    name: `credits`,
    description: `[👋 Public] Veja os meus créditos`,
    type: ApplicationCommandType.ChatInput,

    run: async(client, interaction) => {
        interaction.reply({ 
            embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `${client.user.username}`, iconURL: client.user.displayAvatarURL() })
                .setThumbnail(`${client.user.displayAvatarURL()}`)
                .setDescription(`- Olá **${interaction.user.displayName}**, aqui você pode ver os meus créditos, basta apenas ler algumas informações abaixo.`)
                .addFields(
                    {
                        name: `Developer Bot`, value: `\`@gostbanido\``, inline: true
                    },
                    {
                        name: `Meu nome é`, value: `\`${client.user.username}\``, inline: true
                    },
                    {
                        name: `Estou na versão`, value: `\`V2\``, inline: true
                    },
                    {
                        name: `Sou da linguagem`, value: `\`JavaScript\``, inline: true
                    },
                    {
                        name: `Sou um bot`, value: `\`Exclusivo (PAGO)\``, inline: true
                    },
                    {
                        name: `O que faço?`, value: `\`Ajudo pessoas (TICKET)\``, inline: true
                    }
                )
                .setColor(General.get("colorOfice"))
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
                .setTimestamp()
            ]
         })
    }
}