const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const {JsonDatabase} = require("wio.db");
const { ranking, General } = require("../../DataBaseJson")
const { owner } = require("../../config.json")


module.exports ={ 
    name:"ranking",
    description:"[🔒 Owner] Veja o ranking de ticket assumidos",
    type:ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
      
        if (interaction.user.id !== owner) { interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Espere! Você não tem permissão para usar este comando`, iconURL: "https://cdn.discordapp.com/emojis/1242108596662177872.png?size=2048" }).setColor(General.get("colorOfice"))], ephemeral: true }); return; }

        if (ranking.all().length <= 0) {
            interaction.reply({ embeds: [new EmbedBuilder().setAuthor({ name: `Erro ao puxar o rank, nenhum staff assumiu um ticket ainda!`, iconURL: "https://cdn.discordapp.com/emojis/1242108596662177872.png?size=2048" }).setColor(General.get("colorOfice"))], ephemeral: true });
            return;
        }

        const data = ranking.all().sort((a, b) => b.data - a.data).slice(0, 10);
        
        let description = '**Este é o ranking de atendimento staff os 10 staff\'s com maior colocação estarão nesse ranking**\n';
        data.forEach((item, index) => {
            description += `\n**${index + 1}. Lugar** (<@${item.ID}> que tem \`${item.data}\` ticket's assumido's)`;
        });

        const embed = new EmbedBuilder()
            .setTitle('Ranking de quem mais Assumiu')
            .setDescription(description)
            .setColor(General.get("colorOfice"))
            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp()

        interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
    }
}
