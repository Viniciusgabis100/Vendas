const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommand, ApplicationCommandType, SelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { owner } = require("../config.json")
const { General } = require("../DataBaseJson/index")

async function gerenciarCargos(client, interaction) {
    interaction.update({
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Ticket Tópico V2`, iconURL: client.user.displayAvatarURL() })
            .setDescription(`- **Selecione abaixo qual cargo você deseja configurar:**`)
            .addFields(
                {
                    name: `Cargo Staff`, value: `${General.get("cargoSuportt") === "" ? "\`Não definido.\`" : interaction.guild.roles.cache.get(General.get("cargoSuportt"))}`, inline: true
                },
                {
                    name: `Cargo Membro`, value: `${General.get("cargoMember") === null ? "\`Não definido.\`" : interaction.guild.roles.cache.get(General.get("cargoMember"))}`, inline: true
                }
            )
            .setColor(General.get("colorOfice"))
            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId(`changeCargoStaff`).setLabel(`Cargo Staff`).setEmoji(`1242108655860711504`).setStyle(General.get("buttonsColor")),
                new ButtonBuilder().setCustomId(`changeCargoMember`).setLabel(`Cargo Membro`).setEmoji(`1242108581537517610`).setStyle(General.get("buttonsColor")),
                new ButtonBuilder().setCustomId(`voltarPanel`).setLabel(`Voltar`).setEmoji(`1242108570472812625`).setStyle(2)
            )
        ],
        ephemeral: true
    })
}

module.exports = {
    gerenciarCargos
}