const { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ApplicationCommand, ApplicationCommandType, SelectMenuBuilder, StringSelectMenuBuilder } = require("discord.js")
const { owner } = require("../config.json")
const { General } = require("../DataBaseJson/index")

async function gerenciarBot(client, interaction) {
    interaction.update({
        content: ``,
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Ticket Tópico V2`, iconURL: client.user.displayAvatarURL() })
            .setDescription(`- **Selecione abaixo qual opção do BOT você deseja configurar:**`)
            .addFields(
                {
                    name: `Name Bot`, value: `\`${client.user.username}\``
                },
                {
                    name: `Avatar Bot`, value: `**[Clique Aqui](${client.user.displayAvatarURL()})**`
                },
                {
                    name: `Banner Bot`, value: `${client.user.bannerURL() === undefined ? "\`Não definido.\`" : `**[Clique Aqui](${client.user.bannerURL()})**`}`
                }
            )
            .setColor(General.get("colorOfice"))
            .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp()
        ],
        components: [
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId(`gerenciarBotName`).setLabel(`Alterar Nome`).setEmoji(`1242110765708742656`).setStyle(General.get("buttonsColor")),
                new ButtonBuilder().setCustomId(`gerenciarBotAvatar`).setLabel(`Alterar Avatar`).setEmoji(`1242109062234243123`).setStyle(General.get("buttonsColor")),
                new ButtonBuilder().setCustomId(`gerenciarBotBanner`).setLabel(`Alterar Banner`).setEmoji(`1242109062234243123`).setStyle(General.get("buttonsColor")),
                new ButtonBuilder().setCustomId(`gerenciarBotStatus`).setLabel(`Alterar Status`).setEmoji(`1242109053535260684`).setStyle(General.get("buttonsColor"))
            ),
            new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setURL(`https://discord.com/oauth2/authorize?client_id=${interaction.client.application.id}&scope=bot%20applications.commands&permissions=8`).setLabel(`Adicionar Bot`).setEmoji(`1242108575870877717`).setStyle(5),
                new ButtonBuilder().setCustomId(`voltarPanel`).setLabel(`Voltar`).setEmoji(`1242108570472812625`).setStyle(2)
            )
        ],
        ephemeral: true
    })
}

module.exports = {
    gerenciarBot
}