const { ApplicationCommandType, PermissionsBitField, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require("discord.js");
const { db, logs, perms, stock, userss } = require("../..");

module.exports = {
    name: "botconfig",
    description: "Configure o sistema de feedback",
    type: ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        const { user, member, guild } = interaction;

        
        if (!member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({
            content: 'Você tem permissões de `Gerenciar Servidor` e pode configurar o sistema de feedback.',
            ephemeral: true
        });

        const g = await db.get(`${guild.id}`);
        if(!g) await db.set(`${guild.id}`, {
            "channel_feedback": null,
            "feedbacks": [
                "10/10",
                "top",
                "gostei",
                "loja boa",
                "parabéns"
            ],
            "message": {
                "content": "# FEEDBACK\n- Resgate sua recompensa",
                "embeds": []
            },
            "button": {
                "style": 3,
                "label": "Resgatar",
                "emoji": "🎁"
            }
        });

        interaction.reply({
            embeds: [
                new EmbedBuilder()
                .setTitle(`🎁 Configure o seu bot de avaliações`)
                .setDescription("Configure o seu bot de avaliações de acordo com as suas preferências.")
            ],
            components: [
                new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                    .setCustomId("config_bot")
                    .setPlaceholder("🤖 - Configure o seu bot.")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions(
                        {
                            label:"Alterar nome do bot",
                            emoji:"🤖",
                            value:"name"
                        },
                    )
                ),
                new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                    .setCustomId("config_msg")
                    .setPlaceholder("💬 - Configure as mensagems")
                    .setMaxValues(1)
                    .setMinValues(1)
                    .addOptions(
                        {
                            label:"Configurar canal de avaliações",
                            emoji:"❤",
                            value:"channel_avaliation"
                        },
                        {
                            label:"Configurar feedbacks permitidos",
                            emoji:"✨",
                            value:"feedbackspermission"
                        },
                        {
                            label:"Configurar mensagem de resgate",
                            emoji:"🔧",
                            value:"msg_resgat"
                        },
                        {
                            label:"Configurar estoque de nitro",
                            emoji:"➕",
                            value:"stock_nitro"
                        },
                    )
                )
            ],
            ephemeral: true
        });
        
    }
}
