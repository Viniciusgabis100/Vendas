const { ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const { owner } = require("../../../config.json");
const { perms } = require("../..");



module.exports = {
    name:"permremove",
    description:"remover permissão para algum staff",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name:"user",
            type: ApplicationCommandOptionType.User,
            required: true,
            description:"Escolha o usuário"
        }
    ],
    run: async(client, interaction) => {
        const { user, options } = interaction;
        
        try {
            if(user.id !== owner) return interaction.deferReply({ ephemeral: true }).catch(() => {});
        } catch {}

        const userPerm = options.getUser("user");

        await perms.delete(`${userPerm.id}`);

        interaction.reply({content:"Removido com sucesso!", ephemeral: true})
    }
}