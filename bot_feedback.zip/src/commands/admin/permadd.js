const { ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const { owner } = require("../../../config.json");
const { perms } = require("../..");



module.exports = {
    name:"permadd",
    description:"Adicionar permissão para algum staff",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
            name:"user",
            description:"Escolha o usuário",
            type: ApplicationCommandOptionType.User,
            required: true,
        }
    ],
    run: async(client, interaction) => {
        const { user, options } = interaction;
        
        try {
            if(user.id !== owner) return interaction.deferReply({ ephemeral: true }).catch(() => {});
        } catch {}

        const userPerm = options.getUser("user");

        await perms.set(`${userPerm.id}`, "Adicionado");

        interaction.reply({content:"Adicionado com sucesso!", ephemeral: true})
    }
}