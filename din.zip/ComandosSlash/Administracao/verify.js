const Discord = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: "verify",
    description: "Enviar Botão de Verificação",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has("Administrator")) {
            interaction.reply({ content: `Você não possui permissão para utilizar este comando. 🔴`, ephemeral: true });
            setTimeout(() => { interaction.deleteReply(); }, 3000);
        } else {
            
            const botao = new Discord.ButtonBuilder()
                .setLabel("Verificar-se")
                .setURL("https://discord.com/oauth2/authorize?client_id=1241397849195810846&redirect_uri=https://restorecord.com/api/callback&response_type=code&scope=identify+guilds.join+email&state=1250189025189298226")
                .setStyle("Link");
            const botao2 = new Discord.ButtonBuilder()
                .setCustomId('faq')
                .setLabel('Por que se verificar?')
                .setStyle("Secondary");
            let row = new Discord.ActionRowBuilder().addComponents(botao, botao2);
            
            // Adicione o URL da imagem desejada no conteúdo da mensagem
            await interaction.channel.send({ content: "# __Verificação Flay Store__\n - Sua verificação é crucial para garantir a segurança do servidor e manter nossa comunidade protegida.\n - Também é essencial concluir a verificação para realizar compras no servidor e não perder o acesso aos nossos serviços.", 
                                             components: [row],
                                             files: ["https://cdn.discordapp.com/attachments/1249858017567051867/1249858161356308500/banner.png?ex=6678a69e&is=6677551e&hm=a24732808c187bdf10506723337ec053b1d1d33f2d64e0d8278fee618fa65640&"] }); // Substitua "URL_DA_IMAGEM_AQUI" pelo URL real da imagem
            interaction.reply({ content: `✅`, ephemeral: true });
        }
    }
};