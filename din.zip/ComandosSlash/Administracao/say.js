const Discord = require("discord.js")
const config = require("../../config.json")
const { getPermissions } = require("../../Functions/PermissionsCache.js");

module.exports = {
    name: "say",
    description: "Enviar Mensagem",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'texto',
            description: 'Oque Deseja Enviar?.',
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }
    ],
    run: async (Client, interaction) => {

        const perm = await getPermissions(client.user.id);
        if (perm === null || !perm.includes(interaction.user.id)) {
            return interaction.reply({ content: `❌ | Você não possui permissão para usar esse comando.`, ephemeral: true });
        } else {
            let dados = interaction.options.getString('texto')
                interaction.reply({ content: `✅ | Mensagem enviada com êxito. Verifique agora mesmo!`, ephemeral: true })
                interaction.channel.send({content: `${dados}`})
                setTimeout(() => { interaction.deleteReply(); }, 5000);
            }

        }

    }